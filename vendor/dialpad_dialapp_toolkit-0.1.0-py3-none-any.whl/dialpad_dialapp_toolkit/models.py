"""The contract's schemas, shared by partner backends and the frontend SDK."""

from __future__ import annotations

from typing import Any, Self

from pydantic import BaseModel, ConfigDict, Field, SecretStr, model_validator

#: The `version` the page data element carries. The frontend SDK rejects versions it doesn't know.
PAGE_DATA_VERSION = 1

#: The id of the `<script type="application/json">` element carrying the page data.
PAGE_DATA_ELEMENT_ID = 'dialpad-page-data'

#: Default prefix for the contract endpoints (`<prefix>/connection`, `<prefix>/disconnect`).
DEFAULT_API_PREFIX = '/dialpad'

DIALPAD_ORIGIN_PRODUCTION = 'https://dialpad.com'
DIALPAD_ORIGIN_BETA = 'https://dialpadbeta.com'


class IdTokenClaims(BaseModel):
  """What decoding a Dialpad idtoken returns.

  The `csr` claim is dropped while decoding and never exposed, and unknown claims are ignored so new
  claims from Dialpad don't break partners. `api_key` is server-side only: `PageData` has no field
  for it.
  """

  model_config = ConfigDict(extra='ignore', frozen=True)

  user_id: int
  company_id: int
  office_id: int
  name: str | None = None
  email: str | None = None
  phone_number: str | None = None
  image_url: str | None = None
  api_key: SecretStr = Field(description=(
      'Dialpad public API key for this user and app. Server-side only: never rendered into the '
      'page or sent to the browser.'),)


class PageUser(BaseModel):
  """The non-sensitive idtoken claims: everything except `api_key` and `csr`."""

  model_config = ConfigDict(extra='forbid', frozen=True)

  user_id: int
  company_id: int
  office_id: int
  name: str | None = None
  email: str | None = None
  phone_number: str | None = None
  image_url: str | None = None

  @classmethod
  def from_claims(cls, claims: IdTokenClaims) -> Self:
    """Build the page's user from decoded claims, leaving the API key behind."""
    return cls.model_validate(claims.model_dump(exclude={'api_key'}))


class ConnectionStatus(BaseModel):
  """Whether this Dialpad user has a working connection to the partner's system."""

  model_config = ConfigDict(extra='forbid', frozen=True)

  connected: bool = Field(description=(
      "Whether this Dialpad user has a working CRM connection in the partner's store"),)
  account_name: str | None = Field(
      default=None,
      description='Shown in the Connect experience, for example the CRM org name',
  )
  authorize_url: str | None = Field(
      default=None,
      description='Where the Connect button sends the user, required when `connected` is false',
  )

  @model_validator(mode='after')
  def _require_authorize_url(self) -> Self:
    if not self.connected and not self.authorize_url:
      msg = 'authorize_url is required when connected is false'
      raise ValueError(msg)
    return self


class PageData(BaseModel):
  """Embedded in the page by the toolkit and read by the frontend SDK."""

  model_config = ConfigDict(extra='forbid', frozen=True)

  dialpad_origin: str = Field(
      description='The Dialpad origin for this environment; the SDK talks only to it',)
  api_prefix: str = Field(
      default=DEFAULT_API_PREFIX,
      description='Prefix for the contract endpoints',
  )
  access_token: str = Field(description="The partner's own access token for this Dialpad user",)
  user: PageUser
  connection: ConnectionStatus = Field(
      description='The status at render time, so the first paint needs no extra request',)
  app: dict[str, Any] | None = Field(
      default=None,
      description='Partner-defined bootstrap data, passed through as JSON',
  )


class ErrorResponse(BaseModel):
  """Returned with `401` on a bad or missing idtoken and `403` when the partner refuses the user."""

  model_config = ConfigDict(extra='forbid', frozen=True)

  code: str
  message: str
