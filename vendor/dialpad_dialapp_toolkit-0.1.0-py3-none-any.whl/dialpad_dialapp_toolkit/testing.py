"""Test helpers: a mock idtoken encoder, a fixed test secret, and model factories.

The default identity (user 5432, company 12345, office 54321) matches the frontend SDK's helpers;
both are checked against `contract/fixtures/default-identity.json` in the repository.

Partner backends import these from their own tests (and local mode), never from production code:
`encode_mock_idtoken()` to call the page route as Dialpad would, and `make_claims()` /
`make_page_data()` to build valid models without repeating every field.
"""

from __future__ import annotations

from typing import Any

from joserfc import jwe, jwt
from joserfc.jwk import OctKey

from dialpad_dialapp_toolkit.idtoken import (
    JWE_ALGORITHM,
    JWE_ENCRYPTION,
    JWE_KEY_LENGTH,
    JWT_ALGORITHM,
)
from dialpad_dialapp_toolkit.models import (
    DEFAULT_API_PREFIX,
    ExternalConnection,
    IdTokenClaims,
    PageData,
)

#: A fixed 50-character client secret, the length Dialpad generates, for tests and local mode.
#: Never use it for a real app.
TEST_CLIENT_SECRET = 'test-client-secret-0123456789-abcdefghijklmnopqrst' # noqa: S105 - a test fixture

#: The placeholder API key mock tokens carry unless a real one is passed.
MOCK_API_KEY = 'mock-api-key'

DEFAULT_USER_ID = 5432
DEFAULT_COMPANY_ID = 12345
DEFAULT_OFFICE_ID = 54321
DEFAULT_NAME = 'Jane Agent'
DEFAULT_EMAIL = 'jane.agent@example.com'
DEFAULT_PHONE_NUMBER = '+15555550100'
DEFAULT_IMAGE_URL = 'https://example.com/avatars/jane-agent.png'

DEFAULT_IDENTITY: dict[str, Any] = {
    'user_id': DEFAULT_USER_ID,
    'company_id': DEFAULT_COMPANY_ID,
    'office_id': DEFAULT_OFFICE_ID,
    'name': DEFAULT_NAME,
    'email': DEFAULT_EMAIL,
    'phone_number': DEFAULT_PHONE_NUMBER,
    'image_url': DEFAULT_IMAGE_URL,
}

DEFAULT_DIALPAD_ORIGIN = 'https://dialpad.com'
DEFAULT_ACCESS_TOKEN = 'mock-access-token' # noqa: S105 - a placeholder, not a credential
DEFAULT_AUTHORIZE_URL = 'https://partner.example.com/oauth/authorize'
#: The OAuth client name `make_page_data()` uses, keying its one authorization URL.
DEFAULT_CLIENT_NAME = 'mock-crm'


def encode_mock_idtoken(secret: str, *, api_key: str = MOCK_API_KEY, **claims: object) -> str:
  """Return a token in Dialpad's exact format, signed with `secret` (never the environment).

  Called from partner tests (and the `create_idtoken` command) to produce the `idtoken` query
  parameter for a page request; `decode_idtoken()` with the same secret returns its claims. Every
  claim has a default (the default identity) and can be overridden; extra keyword arguments become
  extra claims, so tests can add a `csr` claim or one Dialpad might add later.

  Raises `ValueError` when `secret` is shorter than 48 characters.
  """
  if len(secret) < JWE_KEY_LENGTH:
    msg = f'secret must be at least {JWE_KEY_LENGTH} characters'
    raise ValueError(msg)
  payload = {**DEFAULT_IDENTITY, 'api_key': api_key, **claims}
  inner = jwt.encode({'alg': JWT_ALGORITHM}, payload, OctKey.import_key(secret.encode()))
  return jwe.encrypt_compact(
      {
          'alg': JWE_ALGORITHM,
          'enc': JWE_ENCRYPTION
      },
      inner,
      OctKey.import_key(secret[:JWE_KEY_LENGTH].encode()),
      algorithms=[JWE_ALGORITHM, JWE_ENCRYPTION],
  )


def make_claims(**overrides: object) -> IdTokenClaims:
  """Return valid `IdTokenClaims`: the default identity and `mock-api-key`, overridable.

  For tests of code that takes decoded claims, without encoding and decoding a token.
  """
  return IdTokenClaims.model_validate({**DEFAULT_IDENTITY, 'api_key': MOCK_API_KEY, **overrides})


def make_page_data(**overrides: object) -> PageData:
  """Return valid `PageData`, not connected, with one authorization URL; fields overridable.

  For tests that render a page or check what the frontend receives. `external_connection` accepts
  a model or a plain dictionary; the result is validated, so an invalid override raises pydantic's
  `ValidationError`.
  """
  values: dict[str, Any] = {
      'dialpad_origin': DEFAULT_DIALPAD_ORIGIN,
      'api_prefix': DEFAULT_API_PREFIX,
      'access_token': DEFAULT_ACCESS_TOKEN,
      'external_connection': ExternalConnection(
          connected=False,
          authorization_urls={DEFAULT_CLIENT_NAME: DEFAULT_AUTHORIZE_URL},
          name=DEFAULT_CLIENT_NAME,
      ),
      'app': None,
  }
  values.update(overrides)
  return PageData.model_validate(values)
