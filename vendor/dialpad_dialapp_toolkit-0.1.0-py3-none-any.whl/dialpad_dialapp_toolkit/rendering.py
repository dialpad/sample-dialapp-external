"""Rendering the panel page, the close-popup page and error pages, with their security headers."""

from __future__ import annotations

import re
import secrets
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any
from urllib.parse import urljoin, urlsplit

from jinja2 import Environment, PackageLoader, select_autoescape

from dialpad_dialapp_toolkit.models import (
    PAGE_DATA_ELEMENT_ID,
    PAGE_DATA_VERSION,
    ErrorResponse,
    PageData,
)

if TYPE_CHECKING:
  from collections.abc import Mapping, Sequence

_environment = Environment(
    loader=PackageLoader('dialpad_dialapp_toolkit', 'templates'),
    autoescape=select_autoescape(default=True, default_for_string=True),
    keep_trailing_newline=True,
)


@dataclass(frozen=True)
class RenderedPage:
  """An HTML response: the body, its status code, and the headers it must be served with."""

  html: str
  headers: dict[str, str]
  status: int = 200


@dataclass(frozen=True)
class PageAssets:
  """The partner's script and style URLs, and the origins they're served from.

  Scripts are loaded as ES modules. `origins` are added to `script-src` (for assets on a CDN or a
  local Vite dev server); same-origin assets need none.
  """

  scripts: Sequence[str] = ()
  styles: Sequence[str] = ()
  origins: Sequence[str] = ()

  @classmethod
  def from_vite_manifest(
      cls,
      manifest: Mapping[str, Any],
      entry: str,
      base_url: str = '/',
  ) -> PageAssets:
    """Asset tags for one entry of a Vite build manifest (`.vite/manifest.json`).

    `base_url` is where the build output is served, for example `/static/` or a CDN URL. The entry's
    own CSS and the CSS of every chunk it imports are included, in import order.
    """
    if entry not in manifest:
      msg = f'{entry!r} is not in the Vite manifest'
      raise KeyError(msg)

    base = base_url if base_url.endswith('/') else f'{base_url}/'
    styles: list[str] = []
    seen: set[str] = set()

    def collect_css(key: str) -> None:
      if key in seen:
        return
      seen.add(key)
      chunk = manifest[key]
      for imported in chunk.get('imports', []):
        collect_css(imported)
      styles.extend(urljoin(base, css) for css in chunk.get('css', []))

    collect_css(entry)
    origin = _origin_of(base)
    return cls(
        scripts=(urljoin(base, manifest[entry]['file']),),
        styles=tuple(dict.fromkeys(styles)),
        origins=(origin,) if origin else (),
    )


def generate_nonce() -> str:
  """Return a fresh nonce for one response's inline scripts."""
  return secrets.token_urlsafe(18)


# An http(s) origin: scheme, host name or bracketed IPv6 address, optional port. Nothing else.
_ORIGIN = re.compile(
    r'https?://(?:[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?)*|\[[0-9A-Fa-f:.]+\])(?::\d{1,5})?'
)


def _require_origin(value: str) -> str:
  """Return `value` if it's an http(s) origin, such as `https://dialpad.com`.

  The Dialpad origin goes into the Content-Security-Policy header and the close-popup script, so
  anything else (a path, a `;`, whitespace) is refused rather than escaped.
  """
  if not _ORIGIN.fullmatch(value):
    msg = f'expected an origin such as https://dialpad.com, got {value!r}'
    raise ValueError(msg)
  return value


def _origin_of(url: str) -> str | None:
  parts = urlsplit(url)
  if not parts.scheme or not parts.netloc:
    return None
  return f'{parts.scheme}://{parts.netloc}'


def _csp(directives: Sequence[tuple[str, Sequence[str]]]) -> str:
  return '; '.join(' '.join([name, *values]) for name, values in directives)


def _common_headers(csp: str) -> dict[str, str]:
  return {
      'Content-Security-Policy': csp,
      'Referrer-Policy': 'no-referrer',
      'Cache-Control': 'no-store',
      'X-Content-Type-Options': 'nosniff',
  }


@dataclass(frozen=True)
class PageOptions:
  """Optional knobs for `render_page`.

  `extra_connect_src` adds a `connect-src` directive (`'self'` plus these sources), for example the
  Vite dev server's websocket origin in local development.
  """

  title: str = 'Dialpad panel'
  lang: str = 'en'
  mount_id: str = 'app'
  extra_connect_src: Sequence[str] = field(default=())


def render_page(
    page_data: PageData,
    *,
    nonce: str,
    assets: PageAssets,
    options: PageOptions | None = None,
) -> RenderedPage:
  """Render the panel page: the page data element, the partner's assets, and the security headers.

  The page data is embedded as JSON that is safe inside a `<script>` element, together with the
  format `version` the frontend SDK checks. It never contains the API key: `PageData` has no field
  for it.
  """
  opts = options or PageOptions()
  envelope = {'version': PAGE_DATA_VERSION, **page_data.model_dump(mode='json')}
  html = _environment.get_template('page.html').render(
      page_data=envelope,
      page_data_id=PAGE_DATA_ELEMENT_ID,
      nonce=nonce,
      scripts=assets.scripts,
      styles=assets.styles,
      title=opts.title,
      lang=opts.lang,
      mount_id=opts.mount_id,
  )

  directives: list[tuple[str, Sequence[str]]] = [
      ('frame-ancestors', [_require_origin(page_data.dialpad_origin)]),
      ('script-src', ["'self'", f"'nonce-{nonce}'", *dict.fromkeys(assets.origins)]),
      ('object-src', ["'none'"]),
      ('base-uri', ["'none'"]),
  ]
  if opts.extra_connect_src:
    directives.append(('connect-src', ["'self'", *dict.fromkeys(opts.extra_connect_src)]))
  return RenderedPage(html=html, headers=_common_headers(_csp(directives)))


def render_close_popup(dialpad_origin: str, *, nonce: str) -> RenderedPage:
  """Render the page the partner's OAuth callback returns once it has stored the tokens.

  It posts `close_popup` to its opener, to the Dialpad origin only, when it has one (the web), then
  closes itself (the desktop app's login window has no opener). If the browser refuses to close the
  window, it shows a short "you can close this window" message. Raises `ValueError` if
  `dialpad_origin` isn't an http(s) origin.
  """
  html = _environment.get_template('close_popup.html').render(
      dialpad_origin=_require_origin(dialpad_origin),
      nonce=nonce,
  )
  csp = _csp([
      ('default-src', ["'none'"]),
      ('script-src', [f"'nonce-{nonce}'"]),
      ('style-src', [f"'nonce-{nonce}'"]),
      ('frame-ancestors', ["'none'"]),
      ('base-uri', ["'none'"]),
  ])
  return RenderedPage(html=html, headers=_common_headers(csp))


def render_error_page(
    error: ErrorResponse,
    *,
    status: int,
    dialpad_origin: str,
) -> RenderedPage:
  """Render the minimal HTML page for `401` (bad or missing idtoken) or `403` (refused user).

  Raises `ValueError` if `dialpad_origin` isn't an http(s) origin.
  """
  nonce = generate_nonce()
  html = _environment.get_template('error.html').render(error=error, nonce=nonce)
  csp = _csp([
      ('default-src', ["'none'"]),
      ('style-src', [f"'nonce-{nonce}'"]),
      ('frame-ancestors', [_require_origin(dialpad_origin)]),
      ('base-uri', ["'none'"]),
  ])
  return RenderedPage(html=html, headers=_common_headers(csp), status=status)
