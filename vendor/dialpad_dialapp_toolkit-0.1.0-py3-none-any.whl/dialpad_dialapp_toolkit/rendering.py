"""Rendering the panel page, the close-popup page and error pages, with their security headers.

Each render function returns a `RenderedPage`; the partner's route sends its HTML with its status
and all of its headers. `render_page_data()` is for apps that keep their own `index.html`: it
returns just the page data element and the headers. Nothing here keeps state between calls.
"""

from __future__ import annotations

import re
import secrets
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any
from urllib.parse import urljoin, urlsplit

from jinja2 import Environment, PackageLoader, select_autoescape

from dialpad_dialapp_toolkit.models import (
    PAGE_DATA_ELEMENT_ID,
    PAGE_DATA_VERSION,
    ErrorResponse,
    PageData,
)

if TYPE_CHECKING:
  from collections.abc import Mapping, Sequence

_environment = Environment(
    loader=PackageLoader('dialpad_dialapp_toolkit', 'templates'),
    autoescape=select_autoescape(default=True, default_for_string=True),
    keep_trailing_newline=True,
)


@dataclass(frozen=True)
class RenderedPage:
  """An HTML response: the body, its status code, and the headers it must be served with.

  Returned by every render function. Serve the headers as they are: the Content-Security-Policy
  carries the nonce baked into the HTML, and `Cache-Control: no-store` keeps per-user page data out
  of caches.
  """

  html: str
  headers: dict[str, str]
  status: int = 200


@dataclass(frozen=True)
class PageDataElement:
  """The page data `<script>` element and the headers the page carrying it must be served with.

  Returned by `render_page_data()`. Put `html` in your own page template, use the same nonce on your
  own inline scripts, and serve `headers` as they are.
  """

  html: str
  headers: dict[str, str]


@dataclass(frozen=True)
class PageAssets:
  """The partner's script and style URLs, and the origins they're served from.

  Scripts are loaded as ES modules. `origins` are added to `script-src` (for assets on a CDN or a
  local Vite dev server); same-origin assets need none.
  """

  scripts: Sequence[str] = ()
  styles: Sequence[str] = ()
  origins: Sequence[str] = ()

  @classmethod
  def from_vite_manifest(
      cls,
      manifest: Mapping[str, Any],
      entry: str,
      base_url: str = '/',
  ) -> PageAssets:
    """Asset tags for one entry of a Vite build manifest (`.vite/manifest.json`).

    Called by the partner's page route, usually once at startup with the production build's
    manifest. `base_url` is where the build output is served, for example `/static/` or a CDN URL.
    The entry's own CSS and the CSS of every chunk it imports are included, in import order. A
    `base_url` on another origin adds that origin to `origins`.

    Raises `KeyError` when `entry` is not in the manifest.
    """
    if entry not in manifest:
      msg = f'{entry!r} is not in the Vite manifest'
      raise KeyError(msg)

    base = base_url if base_url.endswith('/') else f'{base_url}/'
    styles: list[str] = []
    seen: set[str] = set()

    def collect_css(key: str) -> None:
      if key in seen:
        return
      seen.add(key)
      chunk = manifest[key]
      for imported in chunk.get('imports', []):
        collect_css(imported)
      styles.extend(urljoin(base, css) for css in chunk.get('css', []))

    collect_css(entry)
    origin = _origin_of(base)
    return cls(
        scripts=(urljoin(base, manifest[entry]['file']),),
        styles=tuple(dict.fromkeys(styles)),
        origins=(origin,) if origin else (),
    )


def generate_nonce() -> str:
  """Return a fresh nonce for one response's inline scripts.

  Call it once per request and pass the same value to `render_page()`, `render_page_data()` or
  `render_close_popup()`;
  reusing a nonce across responses defeats the Content-Security-Policy.
  """
  return secrets.token_urlsafe(18)


# An http(s) origin: scheme, host name or bracketed IPv6 address, optional port. Nothing else.
_ORIGIN = re.compile(
    r'https?://(?:[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?)*|\[[0-9A-Fa-f:.]+\])(?::\d{1,5})?'
)


def _require_origin(value: str) -> str:
  """Return `value` if it's an http(s) origin, such as `https://dialpad.com`.

  The Dialpad origin goes into the Content-Security-Policy header and the close-popup script, so
  anything else (a path, a `;`, whitespace) is refused rather than escaped.
  """
  if not _ORIGIN.fullmatch(value):
    msg = f'expected an origin such as https://dialpad.com, got {value!r}'
    raise ValueError(msg)
  return value


def _origin_of(url: str) -> str | None:
  """Return `url`'s origin, or `None` for a relative URL."""
  parts = urlsplit(url)
  if not parts.scheme or not parts.netloc:
    return None
  return f'{parts.scheme}://{parts.netloc}'


def _csp(directives: Sequence[tuple[str, Sequence[str]]]) -> str:
  """Join directives into a Content-Security-Policy header value."""
  return '; '.join(' '.join([name, *values]) for name, values in directives)


def _common_headers(csp: str) -> dict[str, str]:
  """Return the headers every rendered page is served with: the CSP, no referrer, no caching."""
  return {
      'Content-Security-Policy': csp,
      'Referrer-Policy': 'no-referrer',
      'Cache-Control': 'no-store',
      'X-Content-Type-Options': 'nosniff',
  }


@dataclass(frozen=True)
class PageOptions:
  """Optional knobs for `render_page`.

  `extra_connect_src` adds a `connect-src` directive (`'self'` plus these sources), for example the
  Vite dev server's websocket origin in local development.
  """

  title: str = 'Dialpad panel'
  lang: str = 'en'
  mount_id: str = 'app'
  extra_connect_src: Sequence[str] = field(default=())


def render_page_data(
    page_data: PageData,
    *,
    nonce: str,
    script_origins: Sequence[str] = (),
    extra_connect_src: Sequence[str] = (),
) -> PageDataElement:
  """Render only the page data element and the panel page's security headers.

  For apps that keep their own `index.html` (the DialApp framework, or a partner's existing page):
  call it from the page route on every panel open, after `decode_idtoken()` succeeds, put
  `element.html` in the template, give the template's own scripts the same `nonce`, and serve
  `element.headers`. The JSON is safe inside a `<script>` element and carries the format `version`
  the SDK checks; it never contains the API key.

  The Content-Security-Policy lets only the Dialpad origin frame the page and only same-origin
  scripts, `script_origins` (a CDN or a local Vite dev server) and the nonce run scripts;
  `extra_connect_src` adds a `connect-src` directive. Raises `ValueError` if
  `page_data.dialpad_origin` isn't an http(s) origin.
  """
  envelope = {'version': PAGE_DATA_VERSION, **page_data.model_dump(mode='json')}
  html = _environment.get_template('page_data.html').render(
      page_data=envelope,
      page_data_id=PAGE_DATA_ELEMENT_ID,
      nonce=nonce,
  )
  directives: list[tuple[str, Sequence[str]]] = [
      ('frame-ancestors', [_require_origin(page_data.dialpad_origin)]),
      ('script-src', ["'self'", f"'nonce-{nonce}'", *dict.fromkeys(script_origins)]),
      ('object-src', ["'none'"]),
      ('base-uri', ["'none'"]),
  ]
  if extra_connect_src:
    directives.append(('connect-src', ["'self'", *dict.fromkeys(extra_connect_src)]))
  return PageDataElement(html=html.rstrip('\n'), headers=_common_headers(_csp(directives)))


def render_page(
    page_data: PageData,
    *,
    nonce: str,
    assets: PageAssets,
    options: PageOptions | None = None,
) -> RenderedPage:
  """Render the whole panel page: the page data element, the partner's assets, and the headers.

  Called by the partner's page route on every panel open, after `decode_idtoken()` succeeds, when
  the toolkit's minimal page (one mount element) is enough; apps with their own `index.html` use
  `render_page_data()` instead, which this builds on, so both send the same element and headers.
  Once the browser loads the page, the SDK's `createRightbar()` reads the page data and starts.
  Raises `ValueError` if `page_data.dialpad_origin` isn't an http(s) origin.
  """
  opts = options or PageOptions()
  element = render_page_data(
      page_data,
      nonce=nonce,
      script_origins=assets.origins,
      extra_connect_src=opts.extra_connect_src,
  )
  html = _environment.get_template('page.html').render(
      page_data_element=element.html,
      nonce=nonce,
      scripts=assets.scripts,
      styles=assets.styles,
      title=opts.title,
      lang=opts.lang,
      mount_id=opts.mount_id,
  )
  return RenderedPage(html=html, headers=element.headers)


def render_close_popup(dialpad_origin: str, *, nonce: str) -> RenderedPage:
  """Render the page the partner's OAuth callback returns once it has stored the tokens.

  Called by the partner's OAuth callback route at the end of Connect. It posts `close_popup` to its
  opener, to the Dialpad origin only, when it has one (the web), then closes itself (the desktop
  app's login window has no opener). If the browser refuses to close the window, it shows a short
  "you can close this window" message. The panel's SDK then sees the new connection on its next
  status check and shows the user as connected. Raises `ValueError` if `dialpad_origin` isn't an
  http(s) origin.
  """
  html = _environment.get_template('close_popup.html').render(
      dialpad_origin=_require_origin(dialpad_origin),
      nonce=nonce,
  )
  csp = _csp([
      ('default-src', ["'none'"]),
      ('script-src', [f"'nonce-{nonce}'"]),
      ('style-src', [f"'nonce-{nonce}'"]),
      ('frame-ancestors', ["'none'"]),
      ('base-uri', ["'none'"]),
  ])
  return RenderedPage(html=html, headers=_common_headers(csp))


def render_error_page(
    error: ErrorResponse,
    *,
    status: int,
    dialpad_origin: str,
) -> RenderedPage:
  """Render the minimal HTML page for `401` (bad or missing idtoken) or `403` (refused user).

  Called by the partner's page route instead of `render_page()` when `decode_idtoken()` raises or
  the partner refuses the user. The page shows the error's message in the panel, carries no page
  data and runs no scripts, so the SDK never starts. Raises `ValueError` if `dialpad_origin` isn't
  an http(s) origin.
  """
  nonce = generate_nonce()
  html = _environment.get_template('error.html').render(error=error, nonce=nonce)
  csp = _csp([
      ('default-src', ["'none'"]),
      ('style-src', [f"'nonce-{nonce}'"]),
      ('frame-ancestors', [_require_origin(dialpad_origin)]),
      ('base-uri', ["'none'"]),
  ])
  return RenderedPage(html=html, headers=_common_headers(csp), status=status)
