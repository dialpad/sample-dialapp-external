"""Backend toolkit for partner Dialpad rightbar apps.

Decode the idtoken Dialpad appends to the panel's page URL, render the page with its page data and
security headers, and render the close-popup page the partner's OAuth callback returns. Plain
functions and pydantic models, usable from any web framework.
"""

from importlib.metadata import version

from dialpad_dialapp_toolkit.idtoken import IdTokenError, decode_idtoken
from dialpad_dialapp_toolkit.models import (
    DEFAULT_API_PREFIX,
    DIALPAD_ORIGIN_BETA,
    DIALPAD_ORIGIN_PRODUCTION,
    PAGE_DATA_ELEMENT_ID,
    PAGE_DATA_VERSION,
    ConnectionStatus,
    ErrorResponse,
    IdTokenClaims,
    PageData,
    PageUser,
)
from dialpad_dialapp_toolkit.rendering import (
    PageAssets,
    PageOptions,
    RenderedPage,
    generate_nonce,
    render_close_popup,
    render_error_page,
    render_page,
)

__version__ = version('dialpad-dialapp-toolkit')

__all__ = [
    'DEFAULT_API_PREFIX',
    'DIALPAD_ORIGIN_BETA',
    'DIALPAD_ORIGIN_PRODUCTION',
    'PAGE_DATA_ELEMENT_ID',
    'PAGE_DATA_VERSION',
    'ConnectionStatus',
    'ErrorResponse',
    'IdTokenClaims',
    'IdTokenError',
    'PageAssets',
    'PageData',
    'PageOptions',
    'PageUser',
    'RenderedPage',
    '__version__',
    'decode_idtoken',
    'generate_nonce',
    'render_close_popup',
    'render_error_page',
    'render_page',
]
