"""Backend toolkit for partner Dialpad rightbar apps.

Decode the idtoken Dialpad appends to the panel's page URL, render the page with its page data and
security headers, and render the close-popup page the partner's OAuth callback returns. Plain
functions and pydantic models, usable from any web framework.

A typical page route, run each time a Dialpad user opens the panel: `decode_idtoken()` the
`idtoken` query parameter, look up or create the user's connection in the partner's own store,
build `PageData` with its `ExternalConnection`, and return `render_page()`'s HTML with its headers
(or put `render_page_data()`'s element in your own template). Test helpers live in
`dialpad_dialapp_toolkit.testing`; developer commands in `dialpad_dialapp_toolkit.commands`.
"""

from importlib.metadata import version

from dialpad_dialapp_toolkit.idtoken import IdTokenError, decode_idtoken
from dialpad_dialapp_toolkit.models import (
    DEFAULT_API_PREFIX,
    DIALPAD_ORIGIN_BETA,
    DIALPAD_ORIGIN_PRODUCTION,
    PAGE_DATA_ELEMENT_ID,
    PAGE_DATA_VERSION,
    ErrorResponse,
    ExternalConnection,
    IdTokenClaims,
    PageData,
)
from dialpad_dialapp_toolkit.rendering import (
    PageAssets,
    PageDataElement,
    PageOptions,
    RenderedPage,
    generate_nonce,
    render_close_popup,
    render_error_page,
    render_page,
    render_page_data,
)

__version__ = version('dialpad-dialapp-toolkit')

__all__ = [
    'DEFAULT_API_PREFIX',
    'DIALPAD_ORIGIN_BETA',
    'DIALPAD_ORIGIN_PRODUCTION',
    'PAGE_DATA_ELEMENT_ID',
    'PAGE_DATA_VERSION',
    'ErrorResponse',
    'ExternalConnection',
    'IdTokenClaims',
    'IdTokenError',
    'PageAssets',
    'PageData',
    'PageDataElement',
    'PageOptions',
    'RenderedPage',
    '__version__',
    'decode_idtoken',
    'generate_nonce',
    'render_close_popup',
    'render_error_page',
    'render_page',
    'render_page_data',
]
