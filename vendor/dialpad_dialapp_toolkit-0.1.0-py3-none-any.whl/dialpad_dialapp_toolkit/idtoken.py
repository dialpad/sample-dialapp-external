"""Decoding and verifying the idtoken Dialpad appends to the panel's page URL.

The idtoken is a compact JWE (`dir`, `A192CBC-HS384`) keyed with the first 48 characters of the
app's client secret, wrapping an HS256 JWT signed with the full secret. Only those algorithms are
allowed.

Partner backends call `decode_idtoken()` from the panel page route, once per page load, before
rendering anything: the claims say which Dialpad user, company and office opened the panel.
"""

from __future__ import annotations

import json
from typing import Any

from joserfc import jwe, jwt
from joserfc.errors import JoseError
from joserfc.jwk import OctKey
from pydantic import ValidationError

from dialpad_dialapp_toolkit.models import IdTokenClaims

JWE_ALGORITHM = 'dir'
JWE_ENCRYPTION = 'A192CBC-HS384'
JWT_ALGORITHM = 'HS256'

#: Length of the JWE key taken from the client secret. Dialpad generates every client secret at 50
#: characters, so the 48-character key always exists.
JWE_KEY_LENGTH = 48


class IdTokenError(Exception):
  """The idtoken is missing, malformed, not verifiable with this secret, or lacks required claims.

  Raised by `decode_idtoken()`. Callers map it to `401`, typically with `render_error_page()`, and
  render no page data. The message never contains the token or the secret, so it is safe to log.
  """


def _jwe_key(client_secret: str) -> OctKey:
  """Return the JWE key: the first 48 characters of the client secret."""
  if len(client_secret) < JWE_KEY_LENGTH:
    msg = f'client secret must be at least {JWE_KEY_LENGTH} characters'
    raise ValueError(msg)
  return OctKey.import_key(client_secret[:JWE_KEY_LENGTH].encode())


def decode_idtoken(idtoken: str | None, client_secret: str) -> IdTokenClaims:
  """Decrypt and verify a Dialpad idtoken, returning its claims without `csr`.

  Called by the partner's page route with the `idtoken` query parameter and the app's client
  secret. The returned claims identify the Dialpad user, company and office, and carry the user's
  API key, which stays on the server: no claim goes into the page data. Nothing is cached or
  stored; each call decodes from scratch.

  Raises `IdTokenError` for any token that doesn't decode and verify, and `ValueError` when the
  client secret itself is shorter than 48 characters (a configuration error, not a bad token).
  """
  jwe_key = _jwe_key(client_secret)
  if not idtoken:
    msg = 'idtoken is missing'
    raise IdTokenError(msg)

  try:
    encrypted = jwe.decrypt_compact(
        idtoken,
        jwe_key,
        algorithms=[JWE_ALGORITHM, JWE_ENCRYPTION],
    )
    if encrypted.plaintext is None:
      msg = 'idtoken has no payload'
      raise IdTokenError(msg)
    token = jwt.decode(
        encrypted.plaintext,
        OctKey.import_key(client_secret.encode()),
        algorithms=[JWT_ALGORITHM],
    )
  except (JoseError, ValueError, TypeError, json.JSONDecodeError) as error:
    msg = 'idtoken could not be decrypted and verified'
    raise IdTokenError(msg) from error

  claims: dict[str, Any] = dict(token.claims)
  claims.pop('csr', None)
  try:
    return IdTokenClaims.model_validate(claims)
  except ValidationError as error:
    msg = 'idtoken is missing required claims'
    raise IdTokenError(msg) from error
