"""Developer commands, each run as `python -m dialpad_dialapp_toolkit.commands.<name>`.

They are for local development and tests only; partner backends never import them at runtime.
"""
