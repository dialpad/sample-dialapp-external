"""Developer commands, each run as `python -m dialpad_dialapp_toolkit.commands.<name>`."""
