"""Print a mock idtoken.

Run as `python -m dialpad_dialapp_toolkit.commands.create_idtoken --secret <secret>`.

Named like the DialApp framework's `create_idtoken` module. A real idtoken with a working API key
only comes from Dialpad, by opening the panel in dialpadbeta.
"""

from __future__ import annotations

import argparse
import os
import sys
from typing import TYPE_CHECKING
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

from dialpad_dialapp_toolkit.idtoken import JWE_KEY_LENGTH
from dialpad_dialapp_toolkit.testing import MOCK_API_KEY, encode_mock_idtoken

if TYPE_CHECKING:
  from collections.abc import Sequence

SECRET_ENVIRONMENT_VARIABLE = 'DIALPAD_CLIENT_SECRET' # noqa: S105 - the variable's name

_CLAIM_OPTIONS: tuple[tuple[str, str, type], ...] = (
    ('--user-id', 'user_id', int),
    ('--company-id', 'company_id', int),
    ('--office-id', 'office_id', int),
    ('--name', 'name', str),
    ('--email', 'email', str),
    ('--phone-number', 'phone_number', str),
    ('--image-url', 'image_url', str),
)


def _parser() -> argparse.ArgumentParser:
  parser = argparse.ArgumentParser(
      prog='python -m dialpad_dialapp_toolkit.commands.create_idtoken',
      description="Print a mock idtoken in Dialpad's exact format.",
  )
  parser.add_argument(
      '--secret',
      help=f"The app's client secret (default: ${SECRET_ENVIRONMENT_VARIABLE}).",
  )
  parser.add_argument(
      '--api-key',
      default=MOCK_API_KEY,
      help=f'A real Dialpad API key to embed (default: {MOCK_API_KEY}).',
  )
  for flag, dest, value_type in _CLAIM_OPTIONS:
    parser.add_argument(flag, dest=dest, type=value_type, help=f'The {dest} claim.')
  parser.add_argument(
      '--url',
      help='Print this page URL with ?idtoken= added instead of the bare token.',
  )
  return parser


def _with_idtoken(url: str, idtoken: str) -> str:
  parts = urlsplit(url)
  query = [(key, value) for key, value in parse_qsl(parts.query) if key != 'idtoken']
  query.append(('idtoken', idtoken))
  return urlunsplit(parts._replace(query=urlencode(query)))


def main(argv: Sequence[str] | None = None) -> int:
  """Run the command line; returns the exit status."""
  parser = _parser()
  args = parser.parse_args(argv)

  secret = args.secret or os.environ.get(SECRET_ENVIRONMENT_VARIABLE)
  if not secret:
    parser.error(f'pass --secret or set {SECRET_ENVIRONMENT_VARIABLE}')
  if len(secret) < JWE_KEY_LENGTH:
    parser.error(f'the secret must be at least {JWE_KEY_LENGTH} characters')

  claims = {
      dest: getattr(args, dest) for _, dest, _ in _CLAIM_OPTIONS if getattr(args, dest) is not None
  }
  idtoken = encode_mock_idtoken(secret, api_key=args.api_key, **claims)
  sys.stdout.write(f'{_with_idtoken(args.url, idtoken) if args.url else idtoken}\n')
  return 0


if __name__ == '__main__':
  sys.exit(main())
