# @dialpad/dialapp-external-sdk

The SDK for partner apps in Dialpad's right sidebar. It's headless: it ships no
UI components, so you build the panel with your own (the reference app uses Vue
3 and Dialtone 10). The SDK owns everything that talks to Dialpad:

- the host protocol over `postMessage`, which you never call directly;
- one immutable state snapshot: the Dialpad user, the contact being viewed, the
  active call, the theme, and the connection to your system;
- Connect: linking the Dialpad user to your system (for example your CRM)
  through an OAuth popup, completed by polling your backend;
- the panel's height, and the connected state Dialpad's panel menu follows;
- mock Dialpad hosts for unit tests and browser tests.

Your backend renders the panel page with the companion Python package,
`dialpad-dialapp-toolkit`, which puts the page data this SDK reads into the
page.

Supported browsers: Chrome 109 and later, and the Dialpad desktop app. ES
modules only; use a bundler.

## Start

```ts
import { createApp } from 'vue';
import { createRightbar } from '@dialpad/dialapp-external-sdk';
import { rightbarPlugin } from '@dialpad/dialapp-external-sdk/vue';
import App from './App.vue';
import { api } from './api'; // your own HTTP module, with the fetch signature

const root = document.getElementById('app')!;
const rightbar = await createRightbar({ heightRoot: root, fetch: api });
createApp(App).use(rightbarPlugin, rightbar).mount(root);
```

`createRightbar()` rejects with a `RightbarError` whose `code` is `bad_options`,
`not_framed` (the page isn't open inside Dialpad), `bad_page_data` or
`init_timeout`. Show a short "Open this panel from Dialpad" message in that
case.

In a component:

```ts
const { state, authorize, disconnect } = useRightbar();
const contact = computed(() => state.value.contact);
```

## State

```ts
rightbar.state;
// { ready, user, contact, call, theme: { mode, brand },
//   connection: { connected, pending, authorizeUrl, accountName, error } }
```

Every change produces a new snapshot that keeps the references of unchanged
parts. `rightbar.subscribe((next, prev) => …)` and
`rightbar.watch((s) => s.contact, (contact) => …)` follow it. `connection.error`
is `null`, `{ code: 'request_failed', status }`, `{ code: 'network' }` or
`{ code: 'timeout' }`.

## Actions and events

| Call                                                                  | Does                                                                          |
| --------------------------------------------------------------------- | ----------------------------------------------------------------------------- |
| `authorize()`                                                         | Asks Dialpad to open your authorize URL; polls until connected or 2 minutes   |
| `refresh()` / `disconnect()`                                          | Calls your backend's connection and disconnect endpoints                      |
| `authHeaders()`                                                       | `{ Authorization: 'Bearer <access token>' }` for your own API calls           |
| `linkRecord({ type, url })` / `linkRecord(null)`                      | Links a record in your system; turns on "View record" in Dialpad's panel menu |
| `showRefreshButton(show)`, `showToast({ text, type })`, `screenPop()` | Dialpad's refresh button, toasts and screen pops                              |
| `on('rematch' \| 'refreshContact' \| 'createTask', callback)`         | Dialpad's panel menu events; returns an unsubscribe function                  |
| `createRightbar({ onDisconnect })`                                    | Called after a disconnect, from your button or Dialpad's panel menu           |

The panel is about 300 pixels wide and its height follows `heightRoot`, so
confirm actions inline rather than in modal dialogs.

## Testing

| Helper                                                                                 | Entry point      |
| -------------------------------------------------------------------------------------- | ---------------- |
| `createMockHost()`, with `host.createRightbar()`, `advance()`, `settle()`, `received`  | `/testing`       |
| `mountMockHostPage({ src })` for real browsers (Playwright, a dev page)                | `/testing`       |
| `makePageData()`, `makeUser()`, `makeContact()`, `makeCall()`, `disposeAllMockHosts()` | `/testing`       |
| Setup file for Vitest or Jest                                                          | `/testing/setup` |
| `mountWithRightbar(component, options)`                                                | `/vue/testing`   |

```ts
// vitest.config.ts
test: { environment: 'jsdom', setupFiles: ['@dialpad/dialapp-external-sdk/testing/setup'] }
```

`createMockHost()` runs in memory with its own clock, so a Connect test calls
`await host.advance(7_000)` instead of using fake timers. `mountMockHostPage()`
frames your real page, whose backend renders the page data (for example from
`python -m dialpad_dialapp_toolkit.commands.create_idtoken --url <page URL>`),
so it takes no page data itself.
